class InvalidConfigError(Exception):
    pass

class FullyExploredOptimizationDomainError(Exception):
    pass

class InvalidVariableNameError(Exception):
    pass
